package com.sabarecycling.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val green = Color.rgb(24, 112, 68)
    private val dark = Color.rgb(28, 38, 32)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = dark

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 28)
            setBackgroundColor(Color.rgb(246, 250, 246))
        }

        fun heading(text: String, size: Float, color: Int = dark) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(0, 8, 0, 12)
            }

        page.addView(heading("♻️ SABA RECYCLING", 27f, green))
        page.addView(heading("Sell your old clothes & scrap for cash!", 19f))
        page.addView(heading("Doorstep pickup across Bengaluru", 16f, green))
        page.addView(heading(
            "WE BUY\n• Ladies, men's & kids' old clothes\n• Sarees, blankets & textile scrap\n• Metal, plastic, paper & cardboard\n• Old household scrap & appliances",
            17f
        ))
        page.addView(heading(
            "How it works\n1. Contact us on call or WhatsApp\n2. Share your pickup location\n3. We visit, weigh the items and pay you",
            16f
        ))
        page.addView(heading("Bulk and retail quantities accepted", 15f, green))

        val call = Button(this).apply {
            text = "CALL NOW: 96631 73395"
            setOnClickListener { open("tel:9663173395") }
        }
        val whatsapp = Button(this).apply {
            text = "WHATSAPP: 77951 81463"
            setOnClickListener {
                open("https://wa.me/917795181463?text=" +
                    Uri.encode("Hello Saba Recycling, I want to book a scrap pickup."))
            }
        }
        page.addView(call, fullWidth())
        page.addView(whatsapp, fullWidth())
        page.addView(heading("Keep Bengaluru clean and green 🌱", 14f, green))
        setContentView(page)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 10, 0, 10) }

    private fun open(uri: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri))) }
        catch (_: Exception) { }
    }
}
