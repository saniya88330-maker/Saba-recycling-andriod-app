SABA RECYCLING ANDROID APP - STARTER PROJECT

This is the Android Studio source project for a simple information app.
It is not yet a compiled APK and it is not hosted online.

APP DETAILS INCLUDED
- Saba Recycling name and recycling message
- Old clothes, blankets, textile scrap, metal, plastic, paper, cardboard and household scrap
- Bengaluru doorstep pickup information
- Call button: 96631 73395
- WhatsApp button: 77951 81463

HOW TO BUILD THE APK
1. Install Android Studio on a computer.
2. Open this extracted folder in Android Studio.
3. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will create the APK under app/build/outputs/apk/debug/.

HOW TO SHARE A DOWNLOAD LINK
The APK must be uploaded to a trusted HTTPS file host or your own website.
Then share that exact download URL with customers. Android may show an
"Install unknown apps" warning because the app is not from Play Store.
Only customers who trust the source should install it.

IMPORTANT
- Test on several Android phones before sharing.
- For public distribution, prepare a privacy policy if any personal data is collected.
- This starter app does not collect customer details or store bookings.
- Change the app icon/logo and verify all business details before release.
